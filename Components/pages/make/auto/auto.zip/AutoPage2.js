import React from "react";
import { View, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { Divider } from "@rneui/base";
import AppText from "../../../utils/AppText";
import { VictoryPie, VictoryLabel } from "victory-native";

const AutoPage2 = ({ riskLevel, setRiskLevel }) => {
  const riskText = ["안정투자형", "위험중립형", "적극투자형"];
  const riskColor = ["#006400", "#F07C00", "#8B0000"];
  const riskBgColor = ["#90EE90", "#FFDAB9", "#FFB6C1"];
  const stock = [70, 80, 90];
  const safe = [30, 20, 10];

  return (
    <SafeAreaView style={styles.container}>
      <Divider style={styles.topDivider} />
      <View style={styles.container}>
        <View style={styles.textContainer}>
          <AppText style={styles.titleText}>
            포트폴리오의 위험도를 선택해주세요.
          </AppText>
        </View>
        <View style={styles.contentsContainer}>
          {[1, 2, 3].map((level, index) => (
            <TouchableOpacity
              key={index}
              style={[
                styles.input_Risk,
                riskLevel === level
                  ? { backgroundColor: riskBgColor[index] }
                  : null,
              ]}
              onPress={() => {
                setRiskLevel(level);
              }}
            >
              <AppText style={{ color: riskColor[index] }}>
                {riskText[index]}
              </AppText>
            </TouchableOpacity>
          ))}
          <View style={styles.riskInfo}>
            {riskLevel === 1 && (
              <View style={styles.chartContainer}>
                <VictoryPie
                  colorScale={["tomato", "green"]}
                  data={[
                    { x: "주식", y: stock[0] },
                    { x: "안전자산", y: safe[0] },
                  ]}
                  width={300}
                  height={300}
                  labelComponent={
                    <VictoryLabel style={{ fill: "#fff", fontSize: 15 }} />
                  }
                  labelRadius={({ innerRadius }) => innerRadius + 40}
                />
                <View style={styles.infoContainer}>
                  <AppText style={styles.infoText}>
                    • 변동성이 낮고 안정적인 수익을 목표로 하는 투자자에게
                    적합해요
                  </AppText>
                  <AppText style={styles.infoText}>
                    • 안전자산에 투자하는 비율을 높여서 자본 보전을 최우선으로
                    해요
                  </AppText>
                  <AppText style={styles.infoText}>
                    • 주식 {stock[0]}% 안전자산 {safe[0]}%로 자산을 배분해요
                  </AppText>
                </View>
              </View>
            )}
            {riskLevel === 2 && (
              <View style={styles.chartContainer}>
                <VictoryPie
                  colorScale={["tomato", "green"]}
                  data={[
                    { x: "주식", y: stock[1] },
                    { x: "안전자산", y: safe[1] },
                  ]}
                  width={300}
                  height={300}
                  labelComponent={
                    <VictoryLabel style={{ fill: "#fff", fontSize: 15 }} />
                  }
                  labelRadius={({ innerRadius }) => innerRadius + 60}
                />
                <View style={styles.infoContainer}>
                  <AppText style={styles.infoText}>
                    • 위험과 수익의 균형을 맞추고자 하는 투자자에게 적합해요
                  </AppText>
                  <AppText style={styles.infoText}>
                    • 주식과 안전자산을 적절히 혼합하여 중간 정도의 수익과
                    위험이 기대돼요
                  </AppText>
                  <AppText style={styles.infoText}>
                    • 주식 {stock[1]}% 안전자산 {safe[1]}%로 자산을 배분해요
                  </AppText>
                </View>
              </View>
            )}
            {riskLevel === 3 && (
              <View style={styles.chartContainer}>
                <VictoryPie
                  colorScale={["tomato", "green"]}
                  data={[
                    { x: "주식", y: stock[2] },
                    { x: "안전자산", y: safe[2] },
                  ]}
                  width={300}
                  height={300}
                  labelComponent={
                    <VictoryLabel style={{ fill: "#fff", fontSize: 15 }} />
                  }
                  labelRadius={({ innerRadius }) => innerRadius + 70}
                />
                <View style={styles.infoContainer}>
                  <AppText style={styles.infoText}>
                    • 높은 수익을 기대하지만 손실을 감수할 준비가 된 투자자에게
                    적합해요
                  </AppText>
                  <AppText style={styles.infoText}>
                    • 주식에 투자하는 비율을 높여서 수익 기회를 최대한으로
                    하고자 해요
                  </AppText>
                  <AppText style={styles.infoText}>
                    • 주식 {stock[2]}% 안전자산 {safe[2]}%로 자산을 배분해요
                  </AppText>
                </View>
              </View>
            )}
          </View>
          <View style={styles.infoContainer}>
            <AppText style={styles.safeinfoText}>안전자산이란?</AppText>
            <AppText style={styles.safeinfoText}>
              주식과 움직임이 반대인 달러와 금으로 구성되어 있습니다.
            </AppText>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f0f0",
  },
  topDivider: {
    marginTop: 10,
    borderWidth: 4,
    borderColor: "#333",
  },
  safeinfoText: {
    fontSize: 10,
    marginBottom: 0,
    color: "#fff",
  },
  contentsContainer: {
    flex: 1,
    backgroundColor: "#333",
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  textContainer: {
    marginTop: 20,
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  titleText: {
    fontSize: 25,
  },
  input_Risk: {
    backgroundColor: "#fff",
    paddingVertical: 5,
    paddingHorizontal: 15,
    marginBottom: 10,
    borderRadius: 10,
    borderBottomWidth: 1,
    borderColor: "#ccc",
  },
  riskText: {
    fontSize: 16,
  },
  riskInfo: {
    alignItems: "center",
    paddingHorizontal: 0,
  },
  infoContainer: {
    backgroundColor: "transparent",
    padding: 5,
    borderRadius: 10,
    marginTop: 0,
  },
  infoText: {
    alignItems: "start",
    fontSize: 15,
    marginTop: 0,
    marginBottom: 0,
    color: "#fff",
  },
  chartContainer: {
    alignItems: "center",
    marginBottom: 0,
  },
});

export default AutoPage2;
