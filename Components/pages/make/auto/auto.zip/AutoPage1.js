import React from "react";
import { View, TextInput, TouchableOpacity, StyleSheet } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import AppText from "../../../utils/AppText";
import { filteringNumber } from "../../../utils/utils";
import { Button, Divider, Icon } from "@rneui/base";

const AutoPage1 = ({ amount, setAmount }) => {
  const isAmountEnough = () => amount >= 1000000;

  const handleAmount = (value) => {
    const filteredValue = filteringNumber(value);
    setAmount(filteredValue);
  };

  const addValuetoAmount = (value) => {
    setAmount((prevAmount) => Number(prevAmount) + value);
  };

  return (
    <SafeAreaView style={styles.container}>
      <Divider style={styles.topDivider} />
      <View style={styles.textContainer}>
        <AppText style={styles.titleText}>
          얼마를 투자하실 생각이신가요?
        </AppText>
      </View>
      <View style={styles.contentsContainer}>
        <TextInput
          style={styles.inputAmount}
          keyboardType="numeric"
          value={amount.toString()}
          onChangeText={handleAmount}
          placeholder="투자하려는 금액을 입력하세요 (100만원 이상)"
          placeholderTextColor="#fff"
        />
        <View style={styles.buttonRow}>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => addValuetoAmount(100000)}
          >
            <AppText style={styles.buttonText}>+ 10만</AppText>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => addValuetoAmount(1000000)}
          >
            <AppText style={styles.buttonText}>+ 100만</AppText>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => addValuetoAmount(10000000)}
          >
            <AppText style={styles.buttonText}>+ 1000만</AppText>
          </TouchableOpacity>
        </View>
        {amount > 0 && !isAmountEnough() && (
          <AppText style={styles.errorText}>
            최소 100만원 이상 가능합니다.
          </AppText>
        )}
      </View>
      {amount > 0 && !isAmountEnough() && (
        <View style={styles.nextButtonContainer}>
          {/* Add any next button or navigation logic here */}
        </View>
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f0f0f0",
  },
  topDivider: {
    marginTop: 70,
    borderWidth: 4,
    borderColor: "#333",
  },
  contentsContainer: {
    height: "100%",
    backgroundColor: "#333",
    paddingHorizontal: 20,
    paddingVertical: 40,
  },
  textContainer: {
    marginTop: 70,
    paddingHorizontal: 20,
    paddingTop: 0,
    paddingBottom: 10,
  },
  titleText: {
    fontSize: 30,
    fontWeight: "bold",
    color: "#333",
  },
  inputAmount: {
    backgroundColor: "transparent",
    borderBottomWidth: 1,
    borderColor: "#ccc",
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginTop: 20,
    fontSize: 15,
    color: "#fff",
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 20,
  },
  addButton: {
    backgroundColor: "transparent",
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  errorText: {
    fontSize: 15,
    marginTop: 20,
    color: "red",
  },
  nextButtonContainer: {
    position: "absolute",
    bottom: 20,
    left: 20,
    right: 20,
  },
});

export default AutoPage1;
